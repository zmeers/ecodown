library(testthat)
library(ecodown)

test_check("ecodown")
