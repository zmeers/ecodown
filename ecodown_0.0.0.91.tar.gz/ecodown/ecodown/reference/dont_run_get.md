---
title: "Extracts all "don't run" examples in a package"
---

*R/dont_run.R*

## dont_run_get

## Description
 Extracts all "don't run" examples in a package 


## Usage
```r
 
dont_run_get(pkg) 
```

## Arguments
|Arguments|Description|
|---|---|
| pkg | A `pkgdown` package object, or a character path to the location of the package to parse. |







