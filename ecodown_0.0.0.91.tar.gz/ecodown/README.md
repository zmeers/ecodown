
<!-- README.md is generated from README.Rmd. Please edit that file -->

# ecodown <img src="man/figures/logo.png" align="right" alt="" width="130" />

<!-- badges: start -->

[![R-CMD-check](https://github.com/edgararuiz/ecodown/workflows/R-CMD-check/badge.svg)](https://github.com/edgararuiz/ecodown/actions)
[![Lifecycle:
experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#experimental)
[![CRAN
status](https://www.r-pkg.org/badges/version/ecodown)](https://CRAN.R-project.org/package=ecodown)
<!-- badges: end -->

This is a fork of `ecodown`, a package intended for internal RStudio
use. The fork introduces some new features–mainly to integrate the
package with an experimental package I’m writing:`pyrdocs`, an R package
to generate R and Python documentation for Quarto sites.
